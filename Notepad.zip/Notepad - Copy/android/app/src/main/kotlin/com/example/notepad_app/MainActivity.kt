package com.example.notepad_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
