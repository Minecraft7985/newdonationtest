# Full-Stack Flutter Notepad App

A complete full-stack notepad application built with Flutter frontend and Dart backend.

## Features

- Create, read, update, and delete notes
- Clean and intuitive user interface
- Real-time note management
- RESTful API backend
- Cross-platform compatibility

## Project Structure

```
Notepad/
├── lib/                 # Flutter frontend
│   ├── main.dart
│   ├── models/
│   ├── services/
│   ├── screens/
│   └── widgets/
├── backend/             # Dart backend
│   ├── bin/
│   └── pubspec.yaml
├── pubspec.yaml         # Frontend dependencies
└── README.md
```

## Setup Instructions

### Frontend (Flutter)

1. Navigate to the project root:
   ```bash
   cd C:\Users\Devansh Diwan\OneDrive\Desktop\Notepad
   ```

2. Install dependencies:
   ```bash
   flutter pub get
   ```

3. Run the application:
   ```bash
   flutter run
   ```

### Backend (Dart Server)

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   dart pub get
   ```

3. Run the server:
   ```bash
   dart run bin/server.dart
   ```

4. The server will start on `http://localhost:8080`

## API Endpoints

- `GET /notes` - Get all notes
- `POST /notes` - Create a new note
- `PUT /notes/:id` - Update a note
- `DELETE /notes/:id` - Delete a note

## Note Structure

```json
{
  "id": "uuid",
  "title": "Note title",
  "content": "Note content",
  "createdAt": "2024-01-01T00:00:00.000Z",
  "updatedAt": "2024-01-01T00:00:00.000Z"
}
```

## Requirements

- Flutter SDK
- Dart SDK
- Android Studio or VS Code (for Flutter development)

## Development

The app uses:
- Flutter for the frontend UI
- Dart shelf framework for the backend
- HTTP package for API communication
- UUID for unique note identifiers
- Intl for date formatting

## Testing

1. Start the backend server first
2. Run the Flutter app
3. Test CRUD operations by creating, editing, and deleting notes

## Notes

- The backend stores notes in memory (restarting the server will clear all notes)
- For production use, consider adding database persistence
- CORS is enabled for development purposes