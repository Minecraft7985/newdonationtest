import 'package:flutter/material.dart';
import 'package:notepad_app/models/note.dart';
import 'package:notepad_app/services/api_service.dart';
import 'package:notepad_app/widgets/note_card.dart';
import 'package:notepad_app/widgets/note_editor.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final ApiService _apiService = ApiService();
  List<Note> _notes = [];
  bool _isLoading = true;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  String _sortBy = 'updatedAt'; // 'title' or 'updatedAt'

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadNotes() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final notes = await _apiService.getNotes();
      setState(() {
        _notes = notes;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      _showErrorSnackbar('Failed to load notes');
    }
  }

  void _showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _addNote() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const NoteEditor(),
      ),
    );

    if (result != null && result is Note) {
      _loadNotes();
    }
  }

  void _editNote(Note note) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NoteEditor(note: note),
      ),
    );

    if (result != null && result is bool && result) {
      _loadNotes();
    }
  }

  void _deleteNote(Note note) async {
    try {
      await _apiService.deleteNote(note.id);
      _loadNotes();
    } catch (e) {
      _showErrorSnackbar('Failed to delete note');
    }
  }

  Future<void> _togglePin(Note note) async {
    try {
      final updatedNote = note.copyWith(isPinned: !note.isPinned);
      await _apiService.updateNote(updatedNote);
      _loadNotes(); // Reload to reflect changes
    } catch (e) {
      _showErrorSnackbar('Failed to toggle pin');
    }
  }

  List<Note> _getSortedNotes(List<Note> notes) {
    // Separate pinned and unpinned notes
    final pinnedNotes = notes.where((n) => n.isPinned).toList();
    final unpinnedNotes = notes.where((n) => !n.isPinned).toList();

    // Sort pinned notes
    final sortedPinned = List<Note>.from(pinnedNotes)..sort((a, b) {
      if (_sortBy == 'title') {
        return a.title.toLowerCase().compareTo(b.title.toLowerCase());
      } else {
        return b.updatedAt.compareTo(a.updatedAt); // Descending by date
      }
    });

    // Sort unpinned notes
    final sortedUnpinned = List<Note>.from(unpinnedNotes)..sort((a, b) {
      if (_sortBy == 'title') {
        return a.title.toLowerCase().compareTo(b.title.toLowerCase());
      } else {
        return b.updatedAt.compareTo(a.updatedAt); // Descending by date
      }
    });

    // Combine: pinned on top, then unpinned
    return [...sortedPinned, ...sortedUnpinned];
  }

  @override
  Widget build(BuildContext context) {
    final List<Note> filteredNotes = _notes.where((note) =>
      note.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
      note.content.toLowerCase().contains(_searchQuery.toLowerCase())
    ).toList();

    final List<Note> sortedNotes = _getSortedNotes(filteredNotes);

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          decoration: const InputDecoration(
            hintText: 'Search notes...',
            border: InputBorder.none,
          ),
          onChanged: (value) {
            setState(() {
              _searchQuery = value;
            });
          },
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              setState(() {
                _sortBy = value;
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'updatedAt',
                child: Row(
                  children: [
                    Icon(Icons.date_range),
                    SizedBox(width: 8),
                    Text('Sort by Date'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'title',
                child: Row(
                  children: [
                    Icon(Icons.sort_by_alpha),
                    SizedBox(width: 8),
                    Text('Sort by Title'),
                  ],
                ),
              ),
            ],
            icon: const Icon(Icons.sort),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : sortedNotes.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.note_alt_outlined,
                        size: 64,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _searchQuery.isEmpty
                            ? 'No notes yet. Tap + to create one!'
                            : 'No notes found for "$_searchQuery"',
                        style: const TextStyle(fontSize: 18, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      if (_searchQuery.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () {
                            _searchController.clear();
                            setState(() {
                              _searchQuery = '';
                            });
                          },
                          child: const Text('Clear Search'),
                        ),
                      ],
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadNotes,
                  child: ListView.builder(
                    itemCount: sortedNotes.length,
                    itemBuilder: (context, index) {
                      final note = sortedNotes[index];
                      return NoteCard(
                        note: note,
                        onTap: () => _editNote(note),
                        onDelete: () => _deleteNote(note),
                        onTogglePin: () => _togglePin(note),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNote,
        child: const Icon(Icons.add),
      ),
    );
  }
}